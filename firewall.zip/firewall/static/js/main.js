/**
 * Portail Captif - Salle G
 * UIMM Pôle Formation Champagne-Ardenne
 * 
 * JavaScript principal
 */

// =============================================================================
// TOGGLE PANEL FORMATEUR
// =============================================================================

function toggleFormateurPanel() {
    const tab = document.getElementById('formateurTab');
    if (tab) {
        tab.classList.toggle('open');
        
        // Focus sur le premier champ si on ouvre
        if (tab.classList.contains('open')) {
            const firstInput = tab.querySelector('.code-digit');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 300);
            }
        }
    }
}

// Fermer le panel en cliquant à l'extérieur
document.addEventListener('click', (e) => {
    const tab = document.getElementById('formateurTab');
    if (tab && tab.classList.contains('open')) {
        if (!tab.contains(e.target)) {
            tab.classList.remove('open');
        }
    }
});

// Fermer avec Escape
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const tab = document.getElementById('formateurTab');
        if (tab && tab.classList.contains('open')) {
            tab.classList.remove('open');
        }
        closeModal();
    }
});


// =============================================================================
// MODAL DE CONFIRMATION
// =============================================================================

let confirmCallback = null;

function showConfirmModal(title, message, callback) {
    const modal = document.getElementById('confirm-modal');
    const modalTitle = modal.querySelector('.modal-title');
    const modalMessage = document.getElementById('confirm-message');
    const confirmBtn = document.getElementById('confirm-btn');
    
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    confirmCallback = callback;
    
    modal.style.display = 'flex';
    
    // Animation d'entrée
    requestAnimationFrame(() => {
        modal.classList.add('active');
    });
    
    // Focus sur le bouton annuler
    const cancelBtn = modal.querySelector('.btn-secondary');
    if (cancelBtn) {
        cancelBtn.focus();
    }
}

function closeModal() {
    const modal = document.getElementById('confirm-modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 200);
    }
    confirmCallback = null;
}

// Confirmer l'action
document.addEventListener('DOMContentLoaded', () => {
    const confirmBtn = document.getElementById('confirm-btn');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', () => {
            if (confirmCallback) {
                confirmCallback();
            }
            closeModal();
        });
    }
    
    // Fermer en cliquant sur le backdrop
    const modal = document.getElementById('confirm-modal');
    if (modal) {
        const backdrop = modal.querySelector('.modal-backdrop');
        if (backdrop) {
            backdrop.addEventListener('click', closeModal);
        }
    }
});


// =============================================================================
// AUTO-DISMISS DES MESSAGES FLASH
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    const flashMessages = document.querySelectorAll('.flash-message');
    
    flashMessages.forEach((msg, index) => {
        // Auto-dismiss après 5 secondes
        setTimeout(() => {
            msg.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => msg.remove(), 300);
        }, 5000 + (index * 500));
    });
});

// Animation de sortie pour les flash messages
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(styleSheet);


// =============================================================================
// VALIDATION DES FORMULAIRES
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    // Validation du domaine avant soumission
    const addForm = document.querySelector('.add-form');
    if (addForm) {
        addForm.addEventListener('submit', (e) => {
            const domaineInput = document.getElementById('domaine');
            if (domaineInput) {
                let domaine = domaineInput.value.trim().toLowerCase();
                
                // Nettoyer le domaine
                domaine = domaine.replace(/^https?:\/\//, '');
                domaine = domaine.replace(/^www\./, '');
                domaine = domaine.replace(/\/.*$/, '');
                
                // Validation basique
                if (!domaine || domaine.length < 3 || !domaine.includes('.')) {
                    e.preventDefault();
                    alert('Veuillez entrer un domaine valide (ex: exemple.com)');
                    return;
                }
                
                domaineInput.value = domaine;
            }
        });
    }
});


// =============================================================================
// INDICATEUR DE SESSION
// =============================================================================

// Timer de session (15 minutes)
let sessionTimeout = null;
let warningShown = false;

function initSessionTimer() {
    // Reset le timer à chaque activité
    const resetTimer = () => {
        if (sessionTimeout) clearTimeout(sessionTimeout);
        warningShown = false;
        
        // Avertissement à 13 minutes (2 min avant déconnexion)
        sessionTimeout = setTimeout(() => {
            if (!warningShown) {
                warningShown = true;
                showSessionWarning();
            }
        }, 13 * 60 * 1000);
    };
    
    // Écouter l'activité utilisateur
    ['click', 'keypress', 'mousemove', 'scroll'].forEach(event => {
        document.addEventListener(event, resetTimer, { passive: true });
    });
    
    resetTimer();
}

function showSessionWarning() {
    const warning = document.createElement('div');
    warning.className = 'session-warning';
    warning.innerHTML = `
        <div class="warning-content">
            <span class="warning-icon">⏱</span>
            <span class="warning-text">Votre session expire dans 2 minutes</span>
            <button class="warning-dismiss" onclick="this.parentElement.parentElement.remove()">OK</button>
        </div>
    `;
    
    // Styles pour l'avertissement
    warning.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #fef3c7;
        border: 2px solid #f59e0b;
        border-radius: 12px;
        padding: 12px 20px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideUp 0.3s ease;
    `;
    
    document.body.appendChild(warning);
    
    // Auto-remove après 30 secondes
    setTimeout(() => {
        if (warning.parentElement) {
            warning.remove();
        }
    }, 30000);
}

// Initialiser sur les pages admin
if (document.body.classList.contains('page-dashboard') || 
    document.body.classList.contains('page-gestion')) {
    document.addEventListener('DOMContentLoaded', initSessionTimer);
}


// =============================================================================
// ANIMATIONS ET EFFETS
// =============================================================================

// Effet de ripple sur les boutons
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn');
    if (btn && !btn.classList.contains('btn-delete')) {
        const ripple = document.createElement('span');
        const rect = btn.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255,255,255,0.3);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s ease-out;
            pointer-events: none;
        `;
        
        btn.style.position = 'relative';
        btn.style.overflow = 'hidden';
        btn.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    }
});

// Animation ripple
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);


// =============================================================================
// UTILITAIRES
// =============================================================================

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Format date relative
function formatRelativeDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return "À l'instant";
    if (minutes < 60) return `Il y a ${minutes} min`;
    if (hours < 24) return `Il y a ${hours}h`;
    if (days < 7) return `Il y a ${days}j`;
    
    return date.toLocaleDateString('fr-FR');
}
